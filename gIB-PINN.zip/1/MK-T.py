"""
@author: Maziar Raissi
"""
import sys
sys.path.insert(0, '../../Utilities/')
import pandas as pd
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.interpolate import griddata
from pyDOE import lhs
import seaborn as sns
import time
import openpyxl
from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import os
from datetime import datetime
import openpyxl
from openpyxl import Workbook







class PhysicsInformedNN:
    # Initialize the class
    def __init__(self, X_f, layers, lb, ub, X_ui, X_ub, U_i, U_b):

        self.tf_dict = None
        self.lb = lb
        self.ub = ub

        self.x_f = X_f[:, 0:1]
        self.t_f = X_f[:, 1:2]


        self.X_ui = X_ui
        self.X_ub = X_ub
        self.u_i = U_i
        self.u_b = U_b
        self.x_ui = X_ui[:, 0:1]
        self.t_ui = X_ui[:, 1:2]
        self.x_ub = X_ub[:, 0:1]
        self.t_ub = X_ub[:, 1:2]




        self.layers = layers

        self.Loss_set = []  #Total loss
        self.Loss_set_u = []
        self.Loss_set_f = []
        self.cond_layers = {0: [], 1: [], 2: []}

        # Initialize NNs
        self.weights, self.biases = self.initialize_NN(layers)

        # tf placeholders and graph
        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True, log_device_placement=True))

        self.x_f_tf = tf.placeholder(tf.float32, shape=[None, self.x_f.shape[1]])
        self.t_f_tf = tf.placeholder(tf.float32, shape=[None, self.t_f.shape[1]])

        self.x_f_tf = tf.placeholder(tf.float32, shape=[None, self.x_f.shape[1]])
        self.t_f_tf = tf.placeholder(tf.float32, shape=[None, self.t_f.shape[1]])

        self.x_ui_tf = tf.placeholder(tf.float32, shape=[None, self.x_ui.shape[1]])
        self.t_ui_tf = tf.placeholder(tf.float32, shape=[None, self.t_ui.shape[1]])
        self.x_ub_tf = tf.placeholder(tf.float32, shape=[None, self.x_ub.shape[1]])
        self.t_ub_tf = tf.placeholder(tf.float32, shape=[None, self.t_ub.shape[1]])
        self.u_i_tf = tf.placeholder(tf.float32, shape=[None, self.u_i.shape[1]])
        self.u_b_tf = tf.placeholder(tf.float32, shape=[None, self.u_b.shape[1]])

        self.ui_pred = self.net_u(self.x_ui_tf, self.t_ui_tf)
        self.ub_pred = self.net_u(self.x_ub_tf, self.t_ub_tf)
        self.Loss_ui = tf.reduce_mean(tf.square(self.u_i_tf - self.ui_pred))
        self.Loss_ub = tf.reduce_mean(tf.square(self.u_b_tf - self.ub_pred))
        self.Loss_u = self.Loss_ui + self.Loss_ub

        self.ux_i_pred= self.net_i(self.x_ui_tf, self.t_ui_tf)
        self.ut_b_pred = self.net_b(self.x_ub_tf, self.t_ub_tf)
        self.Loss_ux_i = tf.reduce_mean(tf.square(self.ux_i_pred))
        self.Loss_ut_b = tf.reduce_mean(tf.square(self.ut_b_pred))
        self.Loss_ib = self.Loss_ux_i + self.Loss_ut_b

        self.uxx_i_pred = self.net_i2(self.x_ui_tf, self.t_ui_tf)
        self.utt_b_pred = self.net_b2(self.x_ub_tf, self.t_ub_tf)
        self.Loss_uxx_i = tf.reduce_mean(tf.square(self.uxx_i_pred))
        self.Loss_utt_b = tf.reduce_mean(tf.square(self.utt_b_pred))
        self.Loss_ib2 = self.Loss_uxx_i + self.Loss_utt_b

        self.uxxx_i_pred = self.net_i3(self.x_ui_tf, self.t_ui_tf)
        self.uttt_b_pred = self.net_b3(self.x_ub_tf, self.t_ub_tf)
        self.Loss_uxxx_i = tf.reduce_mean(tf.square(self.uxx_i_pred))
        self.Loss_uttt_b = tf.reduce_mean(tf.square(self.utt_b_pred))
        self.Loss_ib3 = self.Loss_uxx_i + self.Loss_utt_b

        self.f_pred = self.net_f(self.x_f_tf, self.t_f_tf)
        self.Loss_f = tf.reduce_mean(tf.square(self.f_pred))

        self.loss = self.Loss_f + self.Loss_u + self.Loss_ib*c1 + self.Loss_ib2*c2 + self.Loss_ib3*c3


        self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.loss,
                                                                method='L-BFGS-B',
                                                                options={'maxiter': 50000,
                                                                         'maxfun': 50000,
                                                                         'maxcor': 50,
                                                                         'maxls': 50,
                                                                         'ftol': 1.0 * np.finfo(float).eps,
                                                                         'disp': False})



        init = tf.global_variables_initializer()
        self.sess.run(init)



    def initialize_NN(self, layers):
        weights = []
        biases = []
        num_layers = len(layers)
        for l in range(0, num_layers - 1):
            W = self.xavier_init(size=[layers[l], layers[l + 1]])
            b = tf.Variable(tf.zeros([1, layers[l + 1]], dtype=tf.float32), dtype=tf.float32)
            weights.append(W)
            biases.append(b)
        return weights, biases

    def xavier_init(self, size):
        in_dim = size[0]
        out_dim = size[1]
        xavier_stddev = np.sqrt(2 / (in_dim + out_dim))
        return tf.Variable(tf.truncated_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)

    def get_weights(self):
        weights_list = self.sess.run(self.weights)
        return weights_list

    def neural_net(self, X, weights, biases):
        num_layers = len(weights) + 1
        H = 2.0 * (X - self.lb) / (self.ub - self.lb) - 1.0
        for l in range(0, num_layers - 2):
            W = weights[l]
            b = biases[l]
            H = tf.tanh(tf.add(tf.matmul(H, W), b))
        W = weights[-1]
        b = biases[-1]
        Y = tf.add(tf.matmul(H, W), b)

        return Y


    def net_u(self, x, t):
        u = self.neural_net(tf.concat([x, t], 1), self.weights, self.biases)
        return u

    def net_f(self, x, t):
        u = self.net_u(x, t)
        u_t = tf.gradients(u, t)[0]
        u_tt = tf.gradients(u_t, t)[0]
        u_x = tf.gradients(u, x)[0]
        u_xx = tf.gradients(u_x, x)[0]
        u_xxx = tf.gradients(u_xx, x)[0]
        f = u_t + 6 * (u ** 2) * u_x + u_xxx  # MKdV
        return f


    def net_i(self, x, t):
        u_prediction = self.net_u(x, t)
        u_exact = (2.0) / tf.cosh(2.0 * x - 8.0 * t)
        u = u_prediction - u_exact
        u_x = tf.gradients(u, x)[0]
        return u_x

    def net_b(self, x, t):
        u_prediction = self.net_u(x, t)
        u_exact = (2.0) / tf.cosh(2.0 * x - 8.0 * t)
        u = u_prediction - u_exact
        u_t = tf.gradients(u, t)[0]
        return u_t

    def net_i2(self, x, t):
        u_prediction = self.net_u(x, t)
        u_exact = (2.0) / tf.cosh(2.0 * x - 8.0 * t)
        u = u_prediction - u_exact
        u_x = tf.gradients(u, x)[0]
        u_xx = tf.gradients(u_x, x)[0]
        return u_xx

    def net_b2(self, x, t):
        u_prediction = self.net_u(x, t)
        u_exact = (2.0) / tf.cosh(2.0 * x - 8.0 * t)
        u = u_prediction - u_exact
        u_t = tf.gradients(u, t)[0]
        u_tt = tf.gradients(u_t, t)[0]
        return u_tt

    def net_i3(self, x, t):
        u_prediction = self.net_u(x, t)
        u_exact = (2.0) / tf.cosh(2.0 * x - 8.0 * t)
        u = u_prediction - u_exact
        u_x = tf.gradients(u, x)[0]
        u_xx = tf.gradients(u_x, x)[0]
        u_xxx = tf.gradients(u_xx, x)[0]
        return u_xxx

    def net_b3(self, x, t):
        u_prediction = self.net_u(x, t)
        u_exact = (2.0) / tf.cosh(2.0 * x - 8.0 * t)
        u = u_prediction - u_exact
        u_t = tf.gradients(u, t)[0]
        u_tt = tf.gradients(u_t, t)[0]
        u_ttt = tf.gradients(u_tt, t)[0]
        return u_ttt


    def callback(self, loss, Loss_f, Loss_u, Loss_ib, Loss_ib2, Loss_ib3):
        print('Loss:', loss, 'Loss_u:', Loss_u, 'Loss_f:', Loss_f)
        print('Loss_ib:', Loss_ib, 'Loss_ib2:', Loss_ib2, 'Loss_ib3:', Loss_ib3)

        print(len(self.Loss_set))
        self.Loss_set.append(loss)
        self.Loss_set_f.append(Loss_f)
        self.Loss_set_u.append(Loss_u)

        return self.Loss_set, self.Loss_set_f, self.Loss_set_u, self.Loss_u, self.Loss_ib



    def train(self):
        for it in range(1):
            self.tf_dict = {self.x_f_tf: self.x_f, self.t_f_tf: self.t_f, self.x_ui_tf: self.x_ui, self.t_ui_tf: self.t_ui,
                            self.x_ub_tf: self.x_ub, self.t_ub_tf: self.t_ub, self.u_i_tf:self.u_i, self.u_b_tf:self.u_b}
            self.optimizer.minimize(self.sess,
                                    feed_dict=self.tf_dict,
                                    fetches=[self.loss, self.Loss_f, self.Loss_u, self.Loss_ib, self.Loss_ib2, self.Loss_ib3],
                                    loss_callback=self.callback)



    def predict(self, X_star):
        u_star = self.sess.run(self.ub_pred, {self.x_ub_tf: X_star[:, 0:1], self.t_ub_tf: X_star[:, 1:2]})
        return u_star




if __name__ == "__main__":












































    r=5234
    N_f=1500
    c2 = 0



    c1 = 1
    c3 = 0

    np.random.seed(r)
    tf.set_random_seed(r)

    k = 30
    N_u1 = 75
    N_u2 = 75



    layers = [2, k, k, k, k, 1]

    beta = 1
    nu = 0.01 / np.pi
    noise = 0.0




    def solution(X, T):
        return (2.0) / np.cosh(2.0 * X - 8.0 * T)#MKdV



    t = np.linspace(-1, 1, 500)
    x = np.linspace(-2, 2, 800)
    X, T = np.meshgrid(x, t)
    u = solution(X, T)
    Exact = u
    X_star = np.hstack((X.flatten()[:, None], T.flatten()[:, None]))
    u_star = Exact.flatten()[:, None]

    # Doman bounds
    lb = X_star.min(0)
    ub = X_star.max(0)

    xx1 = np.hstack((X[0:1, :].T, T[0:1, :].T))
    uu1 = Exact[0:1, :].T
    xx2 = np.hstack((X[:, 0:1], T[:, 0:1]))
    uu2 = Exact[:, 0:1]
    xx3 = np.hstack((X[:, -1:], T[:, -1:]))
    uu3 = Exact[:, -1:]


    X_ub_train = np.vstack([xx2, xx3])
    X_ui_train = np.vstack([xx1])
    ub_train = np.vstack([uu2, uu3])
    ui_train = np.vstack([uu1])

    idxb = np.random.choice(X_ub_train.shape[0], N_u1, replace=False)
    idxi = np.random.choice(X_ui_train.shape[0], N_u2, replace=False)

    X_ub_train = X_ub_train[idxb, :]
    ub_train = ub_train[idxb, :]
    X_ui_train = X_ui_train[idxi, :]
    ui_train = ui_train[idxi, :]


    X_f_train = lb + (ub - lb) * lhs(2, N_f)
    X_u_train = np.vstack([xx1, xx2, xx3])
    X_f_train = np.vstack((X_f_train, X_ui_train, X_ub_train))
    # X_f_train = np.vstack((X_f_train, X_u_train))


    model = PhysicsInformedNN(X_f_train, layers, lb, ub, X_ui_train, X_ub_train, ui_train, ub_train)


    start_time = time.time()
    model.train()
    elapsed = time.time() - start_time
    print('Training time: %.4f' % elapsed)


    u_pred = model.predict(X_star)
    error_u = np.linalg.norm(u_star - u_pred, 2) / np.linalg.norm(u_star, 2)
    print('Error u: %e' % error_u)


    loss_set = model.Loss_set
    loss_u_set = model.Loss_set_u
    loss_f_set = model.Loss_set_f
    Total_loss = loss_set[-1]
    loss_u = loss_u_set[-1]
    loss_f = loss_f_set[-1]

    file_path = r"C:\Users\Public\Desktop\MK_Discussion.xlsx"

    # 检查文件是否存在
    if os.path.exists(file_path):
        # 如果文件存在，打开它
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook.active
    else:
        # 如果文件不存在，创建一个新的工作簿
        workbook = Workbook()
        sheet = workbook.active
        # 添加表头
        sheet.append(["seed", "Cost", "Error u", "Loss", "Loss_u", "Loss_f", "Nuerons", "N_f", "Time", "C1", "C2", "C3"])

    # 获取当前时间戳
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 将数据写入 Excel 文件
    sheet.append([r, elapsed, error_u, Total_loss, loss_u, loss_f, k, N_f, timestamp, c1, c2, c3])

    # 保存文件
    workbook.save(file_path)

    print("数据已成功写入 Excel 文件！")

    # # Exact solution & Predicted solution
    # # Exact soluton
    # U_star = griddata(X_star, u_star.flatten(), (X, T), method='cubic')
    # # Predicted solution
    # U_pred = griddata(X_star, u_pred.flatten(), (X, T), method='cubic')
    #
    #
    # fig_1 = plt.figure(1, figsize=(18, 5))
    # plt.subplot(1, 3, 1)
    # plt.pcolor(X, T, U_star, cmap='jet')
    # plt.colorbar()
    # plt.xlabel(r'$x$')
    # plt.ylabel(r'$t$')
    # plt.title('Exact $u(x)$')
    #
    # plt.subplot(1, 3, 2)
    # plt.pcolor(X, T, U_pred, cmap='jet')
    # plt.colorbar()
    # plt.xlabel(r'$x$')
    # plt.ylabel(r'$t$')
    # plt.title('Predicted $u(x)$')
    #
    # plt.subplot(1, 3, 3)
    # plt.pcolor(X, T, np.abs(U_star - U_pred), cmap='jet')
    # plt.colorbar()
    # plt.xlabel(r'$x$')
    # plt.ylabel(r'$t$')
    # plt.title('Absolute error')
    # plt.tight_layout()
    # plt.show()

