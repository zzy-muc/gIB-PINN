"""
@author: Maziar Raissi
"""

import sys

from scipy.constants import alpha

sys.path.insert(0, '../../Utilities/')
import pandas as pd
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.interpolate import griddata
from pyDOE import lhs
import seaborn as sns
import time
from numpy import log as ln
import os
from datetime import datetime
import openpyxl
from openpyxl import Workbook


class PhysicsInformedNN:
    # Initialize the class
    def __init__(self, X_ui, u_i, X_ub, u_b, ub_t, ui_x, X_u, u, layers, lb, ub):
        self.tf_dict = None
        self.lb = lb
        self.ub = ub

        # Initial and boundary conditions
        self.x_ui = X_ui[:, 0:1]  # Initial condition: x values
        self.t_ui = X_ui[:, 1:2]  # Initial condition: t values
        self.u_i = u_i            # Initial condition: u values
        self.ui_x = ui_x          # Initial condition: du/dx values

        self.x_ub = X_ub[:, 0:1]  # Boundary condition: x values
        self.t_ub = X_ub[:, 1:2]  # Boundary condition: t values
        self.u_b = u_b            # Boundary condition: u values
        self.ub_t = ub_t          # Boundary condition: du/dt values

        # Collocation points
        self.x_u = X_u[:, 0:1]    # Collocation points: x values
        self.t_u = X_u[:, 1:2]    # Collocation points: t values
        self.u = u                # Collocation points: u values

        # Loss history
        self.loss_set = []
        self.Loss_set_u = []
        self.Loss_set_f = []
        self.lambda_1set = []
        self.lambda_2set =[]

        # Neural network architecture
        self.layers = layers
        self.weights, self.biases = self.initialize_NN(layers)

        # Initialize parameters
        self.lambda_1 = tf.Variable(0.5, dtype=tf.float32)
        self.lambda_2 = tf.Variable(1, dtype=tf.float32)

        # TensorFlow placeholders
        self.x_ui_tf = tf.placeholder(tf.float32, shape=[None, self.x_ui.shape[1]])
        self.t_ui_tf = tf.placeholder(tf.float32, shape=[None, self.t_ui.shape[1]])
        self.u_i_tf = tf.placeholder(tf.float32, shape=[None, self.u_i.shape[1]])
        self.ui_x_tf = tf.placeholder(tf.float32, shape=[None, self.ui_x.shape[1]])

        self.x_ub_tf = tf.placeholder(tf.float32, shape=[None, self.x_ub.shape[1]])
        self.t_ub_tf = tf.placeholder(tf.float32, shape=[None, self.t_ub.shape[1]])
        self.u_b_tf = tf.placeholder(tf.float32, shape=[None, self.u_b.shape[1]])
        self.ub_t_tf = tf.placeholder(tf.float32, shape=[None, self.ub_t.shape[1]])

        self.x_u_tf = tf.placeholder(tf.float32, shape=[None, self.x_u.shape[1]])
        self.t_u_tf = tf.placeholder(tf.float32, shape=[None, self.t_u.shape[1]])
        self.u_tf = tf.placeholder(tf.float32, shape=[None, self.u.shape[1]])

        # Neural network predictions
        self.ui_t_pred, self.ui_x_pred = self.net_uib(self.x_ui_tf, self.t_ui_tf)
        self.ub_t_pred, self.ub_x_pred = self.net_uib(self.x_ub_tf, self.t_ub_tf)

        self.u_pred= self.net_u(self.x_u_tf, self.t_u_tf)
        self.f_pred, self.dx, self.dt = self.net_f(self.x_u_tf, self.t_u_tf)

        # Loss functions
        self.Loss_ui = tf.reduce_mean(tf.square(self.ui_x_pred - self.ui_x_tf))  # Initial condition loss
        self.Loss_ub = tf.reduce_mean(tf.square(self.ub_t_pred - self.ub_t_tf))  # Boundary condition loss
        self.Loss_u = tf.reduce_mean(tf.square(self.u_tf - self.u_pred))         # Data loss
        self.Loss_f = tf.reduce_mean(tf.square(self.f_pred))                     # Physics loss
        # self.Loss_g = tf.reduce_mean(tf.square(self.g_pred))
        self.Loss_dx = tf.reduce_mean(tf.square(self.dx))
        self.Loss_dt = tf.reduce_mean(tf.square(self.dt))

        # Total loss
        self.Loss_ib = (self.Loss_ui + self.Loss_ub) * coefficient_matrix      # Combined initial and boundary loss
        self.loss = self.Loss_u + self.Loss_f + self.Loss_ib + self.Loss_dx + self.Loss_dt

        # Optimizers
        self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.loss,
                                                                method='L-BFGS-B',
                                                                options={'maxiter': 50000,
                                                                         'maxfun': 50000,
                                                                         'maxcor': 50,
                                                                         'maxls': 50,
                                                                         'ftol': 1.0 * np.finfo(float).eps,
                                                                         'disp': False})

        self.optimizer_Adam = tf.train.AdamOptimizer(learning_rate=0.0008)
        self.train_op_Adam = self.optimizer_Adam.minimize(self.loss)

        # Initialize TensorFlow session
        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True, log_device_placement=True))
        init = tf.global_variables_initializer()
        self.sess.run(init)

    def initialize_NN(self, layers):
        """
        Initialize neural network weights and biases.
        """
        weights = []
        biases = []
        num_layers = len(layers)
        for l in range(0, num_layers - 1):
            W = self.xavier_init(size=[layers[l], layers[l + 1]])
            b = tf.Variable(tf.zeros([1, layers[l + 1]], dtype=tf.float32), dtype=tf.float32)
            weights.append(W)
            biases.append(b)
        return weights, biases

    def xavier_init(self, size):
        """
        Xavier initialization for neural network weights.
        """
        in_dim = size[0]
        out_dim = size[1]
        xavier_stddev = np.sqrt(2.0 / (in_dim + out_dim))
        return tf.Variable(tf.random_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)

    def neural_net(self, X):
        """
        Neural network forward pass.
        """
        H = 2.0 * (X - self.lb) / (self.ub - self.lb) - 1.0  # Normalize input
        for l in range(0, len(self.layers) - 2):
            W = self.weights[l]
            b = self.biases[l]
            H = tf.tanh(tf.add(tf.matmul(H, W), b))
        W = self.weights[-1]
        b = self.biases[-1]
        Y = tf.add(tf.matmul(H, W), b)
        return Y

    def net_u(self, x, t):
        """
        Neural network for the solution u(x, t).
        """
        X = tf.concat([x, t], axis=1)
        return self.neural_net(X)

    def net_f(self, x, t):
        """
        Physics-informed neural network for the residual f(x, t).
        """
        u = self.net_u(x, t)
        u_t = tf.gradients(u, t)[0]
        u_x = tf.gradients(u, x)[0]
        u_xx = tf.gradients(u_x, x)[0]
        lambda_1 = self.lambda_1
        lambda_2 = self.lambda_2
        p = 1
        q = 0.5
        Res = tf.exp(-alpha * t) * ((p * np.pi**2 - alpha) * tf.sin(np.pi * x) + 0.1 * (p * (beta * np.pi)**2 - alpha) * tf.sin(beta * np.pi * x) + q * np.pi * tf.cos(np.pi * x) + 0.1 * q * beta * np.pi * tf.cos(beta * np.pi * x))
        f = u_t - lambda_1 * u_xx + lambda_2 * u_x - Res  # Example physics equation
        # g = 4*lambda_1*(t**2)*u_t + 4*lambda_1*t*x*u_x + x**2 + 2*lambda_2*t
        dx = tf.gradients(f, x)[0]
        dt = tf.gradients(f, t)[0]
        return f, dx, dt

    def net_uib(self, x, t):
        """
        Neural network for initial and boundary conditions.
        """
        u = self.net_u(x, t)
        u_t = tf.gradients(u, t)[0]
        u_x = tf.gradients(u, x)[0]
        return u_t, u_x

    def callback(self, loss, Loss_u, Loss_f, lambda_1, lambda_2):
        """
        Callback function to track loss during training.
        """
        self.loss_set.append(loss)
        print('Iteration:', len(self.loss_set))
        print('Loss: %e' % loss)
        print('lambda_1:', lambda_1, 'lambda_2:', lambda_2)
        self.Loss_set_u.append(Loss_u)
        self.Loss_set_f.append(Loss_f)
        self.lambda_1set.append(lambda_1)
        self.lambda_2set.append(lambda_2)
        return self.loss_set, self.Loss_set_u, self.Loss_set_f, self.lambda_1set, self.lambda_2set

    def train(self):
        """
        Train the neural network.
        """
        self.tf_dict = {
            self.x_ui_tf: self.x_ui,
            self.t_ui_tf: self.t_ui,
            self.u_i_tf: self.u_i,
            self.ui_x_tf: self.ui_x,
            self.x_ub_tf: self.x_ub,
            self.t_ub_tf: self.t_ub,
            self.u_b_tf: self.u_b,
            self.ub_t_tf: self.ub_t,
            self.x_u_tf: self.x_u,
            self.t_u_tf: self.t_u,
            self.u_tf: self.u
        }

        # Adam optimization
        for it in range(1000):
            self.sess.run(self.train_op_Adam, self.tf_dict)
            if it % 50 == 0:
                loss_value = self.sess.run(self.loss, self.tf_dict)
                print('It: %d, Loss: %.3e' % (it, loss_value))

        # L-BFGS optimization
        self.optimizer.minimize(
            self.sess,
            feed_dict=self.tf_dict,
            fetches=[self.loss, self.Loss_u, self.Loss_f, self.lambda_1, self.lambda_2],
            loss_callback=self.callback
        )

    def predict(self, X_star):
        """
        Predict u(x, t) and lambda_k(x, t) at given points.
        """
        u_star = self.sess.run(self.u_pred, {self.x_u_tf: X_star[:, 0:1], self.t_u_tf: X_star[:, 1:2]})
        return u_star


if __name__ == "__main__":
    k=60

















    r=10234
    N_f=5000
    layers = [2, k, k, k, k, k, k, 1]
    coefficient_matrix = 0


    np.random.seed(r)
    tf.set_random_seed(r)


    N_ui = 150
    N_ub = 150



    alpha=1
    beta=10

    def solution(x, t):
        return np.exp(-alpha * t) * (np.sin(np.pi * x) + 0.1 * np.sin(beta * np.pi * x))


    def dx(x, t):
        return np.exp(-alpha * t) * (np.pi * np.cos(np.pi * x) + 0.1 * beta * np.pi * np.cos(beta * np.pi * x))


    def dt(x, t):
        return -alpha * np.exp(-alpha * t) * (np.sin(np.pi * x) + 0.1 * np.sin(beta * np.pi * x))


    t = np.linspace(0, 5, 800)
    x = np.linspace(0, 2, 256)
    X, T = np.meshgrid(x, t)
    u = solution(X, T)
    Exact = u

    X_star = np.hstack((X.flatten()[:, None], T.flatten()[:, None]))
    u_star = Exact.flatten()[:, None]

    # Doman bounds
    lb = X_star.min(0)
    ub = X_star.max(0)

    xx1 = np.hstack((X[0:1, :].T, T[0:1, :].T))
    uu1 = Exact[0:1, :].T
    xx2 = np.hstack((X[:, 0:1], T[:, 0:1]))
    uu2 = Exact[:, 0:1]
    xx3 = np.hstack((X[:, -1:], T[:, -1:]))
    uu3 = Exact[:, -1:]

    X_ui_train = np.vstack([xx1])
    ui_train = np.vstack([uu1])

    idx_ui = np.random.choice(X_ui_train.shape[0], N_ui, replace=False)
    X_ui_train = X_ui_train[idx_ui, :]
    ui_train = ui_train[idx_ui, :]

    X_ub_train = np.vstack([xx2, xx3])
    ub_train = np.vstack([uu2, uu3])

    idx_ub = np.random.choice(X_ub_train.shape[0], N_ub, replace=False)
    X_ub_train = X_ub_train[idx_ub, :]
    ub_train = ub_train[idx_ub, :]

    idx_ur = np.random.choice(X_star.shape[0], N_f, replace=False)
    X_ur_train = X_star[idx_ur, :]
    ur_train = u_star[idx_ur, :]

    # noise = 0.1
    # ur_train = ur_train + noise*np.std(ur_train)*np.random.randn(ur_train.shape[0], ur_train.shape[1])

    X_u_train = np.vstack([X_ui_train, X_ur_train, X_ub_train])
    u_train = np.vstack([ui_train, ur_train, ub_train])

    Ut_b = np.hstack((dt(X_ub_train[:, 0:1], X_ub_train[:, 1:2]))).reshape([-1,1])
    Ux_i = np.hstack((dx(X_ui_train[:, 0:1], X_ui_train[:, 1:2]))).reshape([-1,1])

    # noise = 0.05
    # u_train = u_train + noise*np.std(u_train)*np.random.randn(u_train.shape[0], u_train.shape[1])
    # Ux_i = Ux_i + noise*np.std(Ux_i)*np.random.randn(Ux_i.shape[0], Ux_i.shape[1])
    # Ut_b = Ut_b + noise*np.std(Ut_b)*np.random.randn(Ut_b.shape[0], Ut_b.shape[1])

    model = PhysicsInformedNN(X_ui_train, ui_train, X_ub_train, ub_train, Ut_b, Ux_i, X_u_train, u_train, layers, lb, ub)



    start_time = time.time()
    model.train()
    elapsed = time.time() - start_time
    # 模拟模型预测
    u_pred = model.predict(X_star)
    # 计算误差
    error_u = np.linalg.norm(u_star - u_pred, 2) / np.linalg.norm(u_star, 2)
    # 记录训练时间和误差

    # 获取训练后的 lambda_1 和 lambda_2
    lambda_1_value = model.sess.run(model.lambda_1)
    lambda_2_value = model.sess.run(model.lambda_2)

    # 计算 lambda_1 和 lambda_2 的相对误差
    error_lambda_1 = np.abs(lambda_1_value - 1) / 1 * 100
    error_lambda_2 = np.abs(lambda_2_value - 0.5) / 0.5 * 100

    # 输出训练时间和误差
    print('Training time: %.4f' % elapsed)
    print('Error u: %e' % error_u)
    print('Error lambda_1: %.5f%%' % (error_lambda_1))
    print('Error lambda_2: %.5f%%' % (error_lambda_2))


# Excel 文件路径
file_path = r"C:\Users\Public\Desktop\results.xlsx"

# 检查文件是否存在
if os.path.exists(file_path):
    # 如果文件存在，打开它
    workbook = openpyxl.load_workbook(file_path)
    sheet = workbook.active
else:
    # 如果文件不存在，创建一个新的工作簿
    workbook = Workbook()
    sheet = workbook.active
    # 添加表头
    sheet.append(["seed", "Time", "Error u", "Error lambda_1", "Error lambda_2", "Nuerons", "N_f", "Timestamp", "C"])

# 获取当前时间戳
timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# 将数据写入 Excel 文件
sheet.append([r, elapsed, error_u, error_lambda_1, error_lambda_2, k, N_f, timestamp,  coefficient_matrix])

# 保存文件
workbook.save(file_path)

print("数据已成功写入 Excel 文件！")