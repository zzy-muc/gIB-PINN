import sys

from scipy.constants import alpha

sys.path.insert(0, '../../Utilities/')
import pandas as pd
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.interpolate import griddata
from pyDOE import lhs
import seaborn as sns
import time
from numpy import log as ln
import os
from datetime import datetime
import openpyxl
from openpyxl import Workbook


class PhysicsInformedNN:
    # Initialize the class
    def __init__(self, X_i, u_i, X_b, u_b, ub_t, ui_x, X_u, u, layers, lb, ub, layers1, t_train):



        self.lb = lb
        self.ub = ub



        # Initial and boundary conditions
        self.x_i = X_i[:, 0:1]  # Initial condition: x values
        self.t_i = X_i[:, 1:2]  # Initial condition: t values
        self.u_i = u_i            # Initial condition: u values
        self.ui_x = ui_x          # Initial condition: du/dx values

        self.x_b = X_b[:, 0:1]  # Boundary condition: x values
        self.t_b = X_b[:, 1:2]  # Boundary condition: t values
        self.u_b = u_b            # Boundary condition: u values
        self.ub_t = ub_t          # Boundary condition: du/dt values
        self.t_train = t_train         #only for lambda

        # Collocation points
        self.x_u = X_u[:, 0:1]    # Collocation points: x values
        self.t_u = X_u[:, 1:2]    # Collocation points: t values
        self.u = u                # Collocation points: u values

        # Loss history
        self.loss_set = []
        self.Loss_set_u = []
        self.Loss_set_f = []
        self.lambda_1set = []
        self.lambda_2set =[]


        # Neural network architecture
        self.layers = layers
        self.layers1 = layers1
        self.weights, self.biases = self.initialize_NN(layers)
        self.weights1, self.biases1 = self.initialize_NN1(layers1)

        # Initialize parameters
        self.l_2_pred = tf.Variable(0.02, dtype=tf.float32)

        # TensorFlow placeholders
        self.x_i_tf = tf.placeholder(tf.float32, shape=[None, self.x_i.shape[1]])
        self.t_i_tf = tf.placeholder(tf.float32, shape=[None, self.t_i.shape[1]])
        self.u_i_tf = tf.placeholder(tf.float32, shape=[None, self.u_i.shape[1]])
        self.i_ux_tf = tf.placeholder(tf.float32, shape=[None, self.ui_x.shape[1]])

        self.x_b_tf = tf.placeholder(tf.float32, shape=[None, self.x_b.shape[1]])
        self.t_b_tf = tf.placeholder(tf.float32, shape=[None, self.t_b.shape[1]])
        self.u_b_tf = tf.placeholder(tf.float32, shape=[None, self.u_b.shape[1]])
        self.b_ut_tf = tf.placeholder(tf.float32, shape=[None, self.ub_t.shape[1]])

        self.x_u_tf = tf.placeholder(tf.float32, shape=[None, self.x_u.shape[1]])
        self.t_u_tf = tf.placeholder(tf.float32, shape=[None, self.t_u.shape[1]])
        self.u_tf = tf.placeholder(tf.float32, shape=[None, self.u.shape[1]])


        self.t_train_tf = tf.placeholder(tf.float32, shape=[None, self.t_train.shape[1]])


        # Neural network predictions
        self.i_ux_pred = self.net_i(self.x_i_tf, self.t_i_tf)
        self.b_ut_pred = self.net_b(self.x_b_tf, self.t_b_tf)

        self.u_pred = self.net_u(self.x_u_tf, self.t_u_tf)
        self.f_pred, self.dx, self.dt = self.net_f(self.x_u_tf, self.t_u_tf)
        self.l_1_pred, self.lt_1_pred = self.neural_net_lambda(self.t_train_tf)

        # Loss functions
        self.Loss_i = tf.reduce_mean(tf.square(self.i_ux_pred - self.i_ux_tf))  # Initial condition loss
        self.Loss_b = tf.reduce_mean(tf.square(self.b_ut_pred - self.b_ut_tf))  # Boundary condition loss
        self.Loss_u = tf.reduce_mean(tf.square(self.u_tf - self.u_pred))         # Data loss
        self.Loss_f = tf.reduce_mean(tf.square(self.f_pred))                     # Physics loss
        self.lambda_0 = self.net_l(self.t_train_tf)

        self.Loss_lambda = tf.reduce_mean(tf.square(self.l_1_pred - self.lambda_0))
        self.Loss_dx = tf.reduce_mean(tf.square(self.dx))
        self.Loss_dt = tf.reduce_mean(tf.square(self.dt))
        self.gPINN = (self.Loss_dx + self.Loss_dt) * gPINN
        # Total loss
        self.Loss_ib = (self.Loss_i + self.Loss_b) * coefficient_matrix      # Combined initial and boundary loss
        self.loss = self.Loss_u + self.Loss_f + self.Loss_ib + self.Loss_lambda
        # self.loss = self.Loss_u + self.Loss_f + self.gPINN + self.Loss_lambda         #gPINN

        # Optimizers
        self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.loss,
                                                                method='L-BFGS-B',
                                                                options={'maxiter': 30000,
                                                                         'maxfun': 30000,
                                                                         'maxcor': 50,
                                                                         'maxls': 50,
                                                                         'ftol': 1.0 * np.finfo(float).eps,
                                                                         'disp': False})

        self.optimizer_Adam = tf.train.AdamOptimizer(learning_rate=0.001)
        self.train_op_Adam = self.optimizer_Adam.minimize(self.loss)

        # Initialize TensorFlow session
        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True, log_device_placement=True))
        init = tf.global_variables_initializer()
        self.sess.run(init)

    def initialize_NN(self, layers):
        """
        Initialize neural network weights and biases.
        """
        weights = []
        biases = []
        num_layers = len(layers)
        for l in range(0, num_layers - 1):
            W = self.xavier_init(size=[layers[l], layers[l + 1]])
            b = tf.Variable(tf.zeros([1, layers[l + 1]], dtype=tf.float32), dtype=tf.float32)
            weights.append(W)
            biases.append(b)
        return weights, biases


    #待定函数网络的初始化
    def initialize_NN1(self, layers1):
        weights1 = []
        biases1 = []
        num_layers1 = len(layers1)
        for l in range(0, num_layers1 - 1):
            W1 = self.xavier_init(size=[layers1[l], layers1[l + 1]])
            b1 = tf.Variable(tf.zeros([1, layers1[l + 1]], dtype=tf.float32), dtype=tf.float32)
            weights1.append(W1)
            biases1.append(b1)
        return weights1, biases1


    def xavier_init(self, size):
        """
        Xavier initialization for neural network weights.
        """
        in_dim = size[0]
        out_dim = size[1]
        xavier_stddev = np.sqrt(2.0 / (in_dim + out_dim))
        return tf.Variable(tf.random_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)

    def neural_net(self, X):
        H = 2.0 * (X - self.lb) / (self.ub - self.lb) - 1.0  # Normalize input
        for l in range(0, len(self.layers) - 2):
            W = self.weights[l]
            b = self.biases[l]
            H = tf.tanh(tf.add(tf.matmul(H, W), b))
        W = self.weights[-1]
        b = self.biases[-1]
        Y = tf.add(tf.matmul(H, W), b)
        return Y

    def neural_net_lambda(self, X):
        H = 2.0 * (X + 2) / 4 - 1.0  # Normalize input
        # H = X
        t = X
        for l in range(0, len(self.layers1) - 2):
            W = self.weights1[l]
            b = self.biases1[l]
            H = tf.tanh(tf.add(tf.matmul(H, W), b))
        W = self.weights1[-1]
        b = self.biases1[-1]
        output = tf.add(tf.matmul(H, W), b)
        output_t = tf.gradients(output, t)[0]  - 2*tf.cos(2*t)
        return output, output_t


    def net_u(self, x, t):
        X = tf.concat([x, t], axis=1)
        u = self.neural_net(X)
        return u

    def net_f(self, x, t):
        # 计算 u 和 lambda_1、_2
        u = self.net_u(x, t)
        lambda_1, _ = self.neural_net_lambda(t)
        lambda_2 = self.l_2_pred
        # 计算 u 的导数
        u_t = tf.gradients(u, t)[0]  # ∂u/∂t
        u_tt = tf.gradients(u_t, t)[0]
        u_x = tf.gradients(u, x)[0]  # ∂u/∂x
        u_xx = tf.gradients(u_x, x)[0]  # ∂²u/∂x²
        u_xxx = tf.gradients(u_xx, x)[0]

        f = u_t + lambda_1 * u * u_x + lambda_1 * u_xxx   #vKdV

        # 计算 f 的偏导数
        f_x = tf.gradients(f, x)[0]  # ∂f/∂x
        f_t = tf.gradients(f, t)[0]  # ∂f/∂t

        # 返回 f 及其偏导数
        return f, f_x, f_t

    def net_i(self, x, t):
        X = tf.concat([x, t], axis=1)
        u_i = self.neural_net(X)
        i_ux = tf.gradients(u_i, x)[0]
        return i_ux

    def net_b(self, x, t):
        X = tf.concat([x, t], axis=1)
        u_b = self.neural_net(X)
        b_ut = tf.gradients(u_b, t)[0]
        return b_ut

    def net_l(self, t):
        lambda_0_1 = 1/2 * tf.exp(t) * tf.cos(tf.exp(t))
        return lambda_0_1

    def callback(self, loss, Loss_u, Loss_f, lambda_1, lambda_2, loss_lambda, loss_ib):
        """
        Callback function to track loss during training.
        """
        self.loss_set.append(loss)
        print('Iteration:', len(self.loss_set))
        print('Loss: %e' % loss, 'Loss_u: %e' % Loss_u, 'Loss_f: %e' % Loss_f, 'Loss_ib: %e' % loss_ib)
        print('lambda_1:', lambda_1[0], lambda_1[-1], 'lambda_2:', lambda_2, 'loss_lambda', loss_lambda)
        self.Loss_set_u.append(Loss_u)
        self.Loss_set_f.append(Loss_f)
        # self.lambda_1set.append(lambda_1)
        self.lambda_2set.append(lambda_2)
        return self.loss_set, self.Loss_set_u, self.Loss_set_f, self.lambda_1set, self.lambda_2set

    def train(self):
        """
        Train the neural network.
        """
        self.tf_dict = {
            self.x_i_tf : self.x_i,
            self.t_i_tf : self.t_i,
            self.u_i_tf : self.u_i,
            self.i_ux_tf : self.ui_x,
            self.x_b_tf : self.x_b,
            self.t_b_tf : self.t_b,
            self.u_b_tf : self.u_b,
            self.b_ut_tf : self.ub_t,
            self.x_u_tf : self.x_u,
            self.t_u_tf : self.t_u,
            self.u_tf : self.u,
            self.t_train_tf: self.t_train
        }

        # Adam optimization
        for it in range(0):
            self.sess.run(self.train_op_Adam, self.tf_dict)
            if it % 50 == 0:
                loss_value = self.sess.run(self.loss, self.tf_dict)
                print('It: %d, Loss: %.3e' % (it, loss_value))

        # L-BFGS optimization
        self.optimizer.minimize(
            self.sess,
            feed_dict=self.tf_dict,
            fetches=[self.loss, self.Loss_u, self.Loss_f, self.l_1_pred, self.l_2_pred, self.Loss_lambda,self.Loss_ib],
            loss_callback=self.callback
        )
    def predict(self, X_star, t_star):

        u_predict = self.sess.run(self.u_pred,{self.x_u_tf: X_star[:, 0:1], self.t_u_tf: X_star[:, 1:2]})
        lambda_u_predict = self.sess.run(self.l_1_pred,{self.t_train_tf: t_star})

        return u_predict, lambda_u_predict


if __name__ == "__main__":







    r=2234
    N_f=5000
    noise = 0.03


    k = 70
    layers = [2, k, k, k, k, k, 1]
    layers1 = [1, 10, 20, 20, 10, 1]
    gPINN = 1

    np.random.seed(r)
    tf.set_random_seed(r)

    coefficient_matrix = 0
    N_ui = 400
    N_ub = 600

    def solution(x, t):
        # return 3 / np.cosh((x - np.sin(t)) / 2) ** 2
        return 3 / np.cosh((x - 1/2*np.sin(np.exp(t))) / 2) ** 2

    def dx(x, t):
        # u = (x - np.sin(t)) / 2
        # return -3 * np.sinh(u) / np.cosh(u) ** 3
        return -3*np.sinh(x/2 - 0.25*np.sin(np.exp(t)))/np.cosh(x/2 - 0.25*np.sin(np.exp(t)))**3

    def dt(x, t):
        # u = (x - np.sin(t)) / 2
        # return 3 * np.cos(t) * np.sinh(u) / np.cosh(u) ** 3
        return 1.5*np.exp(t)*np.cos(np.exp(t))*np.sinh(x/2 - 0.25*np.sin(np.exp(t)))/np.cosh(x/2 - 0.25*np.sin(np.exp(t)))**3


    def lambda1_true(t):
        # return np.sin(t)
        return 1/2 * np.exp(t) * np.cos(np.exp(t))


    t_Train = np.linspace(-2, 2, 2).reshape([2,1])
    t = np.linspace(-2, 2, 501)
    x = np.linspace(-3,3, 601)
    X, T = np.meshgrid(x, t)
    u = solution(X, T)
    Exact = u

    X_star = np.hstack((X.flatten()[:, None], T.flatten()[:, None]))
    u_star = Exact.flatten()[:, None]

    # Doman bounds
    lb = X_star.min(0)
    ub = X_star.max(0)

    xx1 = np.hstack((X[0:1, :].T, T[0:1, :].T))
    uu1 = Exact[0:1, :].T
    xx2 = np.hstack((X[:, 0:1], T[:, 0:1]))
    uu2 = Exact[:, 0:1]
    xx3 = np.hstack((X[:, -1:], T[:, -1:]))
    uu3 = Exact[:, -1:]

    X_i_train = np.vstack([xx1])
    u_i_train = np.vstack([uu1])

    idx_i = np.random.choice(X_i_train.shape[0], N_ui, replace=False)
    X_i_train = X_i_train[idx_i, :]
    u_i_train = u_i_train[idx_i, :]

    X_b_train = np.vstack([xx2, xx3])
    u_b_train = np.vstack([uu2, uu3])

    idx_b = np.random.choice(X_b_train.shape[0], N_ub, replace=False)
    X_b_train = X_b_train[idx_b, :]
    u_b_train = u_b_train[idx_b, :]

    idx_r = np.random.choice(X_star.shape[0], N_f, replace=False)
    X_r_train = X_star[idx_r, :]
    u_r_train = u_star[idx_r, :]

    # noise = 0.1
    # ur_train = ur_train + noise*np.std(ur_train)*np.random.randn(ur_train.shape[0], ur_train.shape[1])

    # X_train = np.vstack([X_i_train, X_r_train, X_b_train])
    # u_train = np.vstack([u_i_train, u_r_train, u_b_train])

    X_train = np.vstack([X_r_train, xx1, xx2, xx3])
    u_train = np.vstack([u_r_train, uu1, uu2, uu3])
    Ut_b = np.hstack((dt(X_b_train[:, 0:1], X_b_train[:, 1:2]))).reshape([-1,1])
    Ux_i = np.hstack((dx(X_i_train[:, 0:1], X_i_train[:, 1:2]))).reshape([-1,1])


    u_train = u_train + noise*np.std(u_train)*np.random.randn(u_train.shape[0], u_train.shape[1])
    Ux_i = Ux_i + noise*np.std(Ux_i)*np.random.randn(Ux_i.shape[0], Ux_i.shape[1])
    Ut_b = Ut_b + noise*np.std(Ut_b)*np.random.randn(Ut_b.shape[0], Ut_b.shape[1])



    model = PhysicsInformedNN(X_i_train, u_i_train, X_b_train, u_b_train, Ut_b, Ux_i, X_train, u_train, layers, lb, ub, layers1, t_Train)

    start_time = time.time()
    model.train()
    elapsed = time.time() - start_time
    u_pred, lambda_1_pred = model.predict(X_star, xx2[:,1:2])
    # 计算误差
    error_u = np.linalg.norm(u_star - u_pred, 2) / np.linalg.norm(u_star, 2)

    lambda_1_true = lambda1_true(t)
    error_lambda_1 = np.linalg.norm(lambda_1_pred.flatten() - lambda_1_true.flatten(), 2) / np.linalg.norm(lambda_1_true.flatten(), 2)
    lambda_2_pred = model.sess.run(model.l_2_pred)
    error_lambda_2 = np.abs(lambda_2_pred - 0.01) / 0.01



    # 输出训练时间和误差
    print('Training time: %.4f' % elapsed)
    print('Error u: %e' % error_u)
    print('Error lambda_1: %e' % (error_lambda_1))
    # print('Error lambda_2: %e' % (error_lambda_2))


    # Excel 文件路径
    file_path = r"C:\Users\Public\Desktop\Inv_Noise-g.xlsx"

    # 检查文件是否存在
    if os.path.exists(file_path):
        # 如果文件存在，打开它
        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook.active
    else:
        # 如果文件不存在，创建一个新的工作簿
        workbook = Workbook()
        sheet = workbook.active
        # 添加表头
        sheet.append(["seed", "Time", "Error u", "Error lambda_1", "Noise", "Nuerons", "N_f", "Timestamp", "C", "layers"])

    # 获取当前时间戳
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 将数据写入 Excel 文件
    sheet.append([r, elapsed, error_u, error_lambda_1, noise, k, N_f, timestamp,  coefficient_matrix, len(layers)-2])

    # 保存文件
    workbook.save(file_path)

    print("数据已成功写入 Excel 文件！")

    #
    # 绘制 lambda_1_pred 和 lambda_1_true 的图形
    plt.figure(figsize=(10, 6))
    plt.plot(t, lambda_1_pred.flatten(), 'b-', linewidth=2, label='Predicted $\lambda_1$')
    plt.plot(t, lambda_1_true.flatten(), 'r--', linewidth=2, label='True $\lambda_1$')

    # 添加标题和标签
    plt.title('Comparison of Predicted and True $\lambda_1$', fontsize=14)
    plt.xlabel('t', fontsize=12)
    plt.ylabel('$\lambda_1$', fontsize=12)
    plt.legend(loc='upper left', fontsize=12)
    plt.grid(True)

    # 显示图形
    plt.show()


    # 将 lambda_1_true 和 lambda_1_pred 写入新的 Excel 文件
    file_path_new = r"C:\Users\Public\Desktop\lambda_1_values.xlsx"  # 新的 Excel 文件路径

    # 如果文件已存在，提示用户并退出
    if os.path.exists(file_path_new):
        print(f"文件 {file_path_new} 已存在，请手动删除或选择其他文件名。")
    else:
        # 创建一个新的工作簿
        workbook_new = Workbook()
        sheet_new = workbook_new.active

        # 添加表头
        sheet_new.append(["t", "lambda_1_true", "lambda_1_pred"])

        # 假设 t 是时间数组，与 lambda_1_true 和 lambda_1_pred 对应
        t = np.linspace(-2, 2, 501)        # 示例时间数组，根据实际情况调整
        lambda_1_true_values = lambda_1_true.flatten()         # 获取 lambda_1_true 的值
        lambda_1_pred_values = lambda_1_pred.flatten()        # 获取 lambda_1_pred 的值

        # 将数据写入 Excel 文件
        for i in range(len(t)):
            sheet_new.append([t[i], lambda_1_true_values[i], lambda_1_pred_values[i]])

        # 保存文件
        workbook_new.save(file_path_new)
        print(f"数据已成功写入新的 Excel 文件：{file_path_new}")